package com.tum.yahtzee.moves;

public interface IBaseMove {
	
	public int getPoints();
	
	public void print();
}
