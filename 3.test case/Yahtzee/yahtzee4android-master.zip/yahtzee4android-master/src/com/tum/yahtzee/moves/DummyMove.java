package com.tum.yahtzee.moves;

public class DummyMove implements IBaseMove{

	public int getPoints() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void print() {
		// TODO Auto-generated method stub
		
	}

}
