package com.tum.yahtzee.services;

public class MethodPointer {
	public void execute()
	{
		
	}
}
